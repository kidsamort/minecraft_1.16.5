[![Build Status](https://dvs1.progwml6.com/jenkins/job/JustEnoughItems-MC1.12/badge/icon)](https://dvs1.progwml6.com/jenkins/job/JustEnoughItems-MC1.12) [![](http://cf.way2muchnoise.eu/full_jei_downloads.svg)](https://minecraft.curseforge.com/projects/jei) [![Discord](https://img.shields.io/discord/358816755646332941.svg?colorB=7289DA&logo=data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHYAAABWAgMAAABnZYq0AAAACVBMVEUAAB38%2FPz%2F%2F%2F%2Bm8P%2F9AAAAAXRSTlMAQObYZgAAAAFiS0dEAIgFHUgAAAAJcEhZcwAACxMAAAsTAQCanBgAAAAHdElNRQfhBxwQJhxy2iqrAAABoElEQVRIx7WWzdGEIAyGgcMeKMESrMJ6rILZCiiBg4eYKr%2Fd1ZAfgXFm98sJfAyGNwno3G9sLucgYGpQ4OGVRxQTREMDZjF7ILSWjoiHo1n%2BE03Aw8p7CNY5IhkYd%2F%2F6MtO3f8BNhR1QWnarCH4tr6myl0cWgUVNcfMcXACP1hKrGMt8wcAyxide7Ymcgqale7hN6846uJCkQxw6GG7h2MH4Czz3cLqD1zHu0VOXMfZjHLoYvsdd0Q7ZvsOkafJ1P4QXxrWFd14wMc60h8JKCbyQvImzlFjyGoZTKzohwWR2UzSONHhYXBQOaKKsySsahwGGDnb%2FiYPJw22sCqzirSULYy1qtHhXGbtgrM0oagBV4XiTJok3GoLoDNH8ooTmBm7ZMsbpFzi2bgPGoXWXME6XT%2BRJ4GLddxJ4PpQy7tmfoU2HPN6cKg%2BledKHBKlF8oNSt5w5g5o8eXhu1IOlpl5kGerDxIVT%2BztzKepulD8utXqpChamkzzuo7xYGk%2FkpSYuviLXun5bzdRf0Krejzqyz7Z3p0I1v2d6HmA07dofmS48njAiuMgAAAAASUVORK5CYII%3D)](https://discord.gg/sCQcWU2)

# JustEnoughItems (JEI)
[JustEnoughItems](https://minecraft.curseforge.com/projects/jei) is an Item and Recipe viewing mod for Minecraft with a focus on stability, performance, and ease of use.

This means:
 * just items and recipes
 * clean API for developers
 * not a coremod – no dependencies other than Forge.

### [JEI Developer Wiki](https://github.com/mezz/JustEnoughItems/wiki)

IRC: [#JEI on EsperNet](https://webchat.esper.net/?nick=JEIGithub...&channels=JEI)
